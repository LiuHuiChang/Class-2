package dao;

import java.util.List;

public interface IRegisterDao {

	boolean checkuser(String uname);

	List getAllCity(String proNo);
}
